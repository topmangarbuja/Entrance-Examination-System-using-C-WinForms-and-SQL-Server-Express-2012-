﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ClassLibrary;
using System.Data.SqlClient;

namespace EntranceExam
{

    public partial class FormTime : Form
    {
        private DataAccess dataAccess;
        int intOriginalTime;

        public FormTime()
        {
            InitializeComponent();
        }

        private void textBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar)==true)
            {
                e.Handled = true;
            }
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            dataAccess = new DataAccess();

            string query = "SELECT period FROM dbo.Duration;";
            dataAccess.RunQueryFillDataSet(query);


            if (dataAccess.errRunQueryFillDataSet != "")
            {
                //Show error message
                MessageBox.Show(dataAccess.errRunQueryFillDataSet, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //Set variable to default
                dataAccess.errRunQueryFillDataSet = "";
            }
            else
            {
                
                intOriginalTime =Convert.ToInt32(dataAccess.dsRunQuery.Tables[0].Rows[0]["period"].ToString());
                txtGetTime.Text = intOriginalTime.ToString();
            }
            
        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            if(txtSetTime.Text.Trim().Length<1)
            {
                //Show error message
                MessageBox.Show("Please enter new time!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);                
            }
            else
            {
                if (intOriginalTime == 0)
                {
                    btnGet_Click(sender, e);
                    txtGetTime.Text = "";
                    SetTime();
                }
                else
                {
                    SetTime();
                }
            }     
          

        }

        private void SetTime()
        {
              dataAccess =new DataAccess();
//            int intTime = Convert.ToInt32(txtSetTime.Text);
              string query = "UPDATE dbo.Duration " +
                  "SET period=@newTime " +
                  "WHERE period=@originalTime;";
            SqlCommand command = new SqlCommand();
            command.CommandText =   query;
            command.Parameters.AddWithValue("@newTime",txtSetTime.Text);
            command.Parameters.AddWithValue("@originalTime",intOriginalTime);

            dataAccess.RunQuery(command);


            if (dataAccess.errRunQuery != "")
            {
                //Show error message
                MessageBox.Show(dataAccess.errRunQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Set variable to default
                dataAccess.errRunQuery = "";                
            }
            else
            {
                //Show error message
                MessageBox.Show("New time successfully set for the Entrance Examination.", "Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information);

                txtSetTime.Text = "";
            }
        }
    }
}
