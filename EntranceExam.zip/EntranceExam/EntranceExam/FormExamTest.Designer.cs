﻿namespace EntranceExam
{
    partial class FormExamTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormExamTest));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtQuestion = new System.Windows.Forms.RichTextBox();
            this.grpGoTo = new System.Windows.Forms.GroupBox();
            this.txtQuestionNo = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnGo = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtOption4 = new System.Windows.Forms.RichTextBox();
            this.txtOption3 = new System.Windows.Forms.RichTextBox();
            this.txtOption1 = new System.Windows.Forms.RichTextBox();
            this.txtOption2 = new System.Windows.Forms.RichTextBox();
            this.rdbOption4 = new System.Windows.Forms.RadioButton();
            this.rdbOption2 = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.rdbOption1 = new System.Windows.Forms.RadioButton();
            this.rdbOption3 = new System.Windows.Forms.RadioButton();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblQuestionId = new System.Windows.Forms.Label();
            this.lblSn = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtRecordPosition = new System.Windows.Forms.TextBox();
            this.btnMovePrevious = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnMoveNext = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lblSection = new System.Windows.Forms.Label();
            this.lblMarks = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.grpGoTo.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("Cambria", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1278, 718);
            this.panel1.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.BackColor = System.Drawing.Color.SteelBlue;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.lblMarks);
            this.panel4.Controls.Add(this.lblSection);
            this.panel4.Controls.Add(this.txtQuestion);
            this.panel4.Controls.Add(this.grpGoTo);
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.btnSubmit);
            this.panel4.Controls.Add(this.lblQuestionId);
            this.panel4.Controls.Add(this.lblSn);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Font = new System.Drawing.Font("Cambria", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(0, 85);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1276, 570);
            this.panel4.TabIndex = 1;
            // 
            // txtQuestion
            // 
            this.txtQuestion.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtQuestion.BackColor = System.Drawing.Color.White;
            this.txtQuestion.Font = new System.Drawing.Font("Cambria", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuestion.Location = new System.Drawing.Point(264, 21);
            this.txtQuestion.Name = "txtQuestion";
            this.txtQuestion.ReadOnly = true;
            this.txtQuestion.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.txtQuestion.Size = new System.Drawing.Size(824, 283);
            this.txtQuestion.TabIndex = 17;
            this.txtQuestion.Text = "";
            // 
            // grpGoTo
            // 
            this.grpGoTo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpGoTo.Controls.Add(this.txtQuestionNo);
            this.grpGoTo.Controls.Add(this.label10);
            this.grpGoTo.Controls.Add(this.btnGo);
            this.grpGoTo.Font = new System.Drawing.Font("Stencil", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpGoTo.Location = new System.Drawing.Point(1095, 124);
            this.grpGoTo.Name = "grpGoTo";
            this.grpGoTo.Size = new System.Drawing.Size(132, 109);
            this.grpGoTo.TabIndex = 16;
            this.grpGoTo.TabStop = false;
            this.grpGoTo.Text = "Go to";
            // 
            // txtQuestionNo
            // 
            this.txtQuestionNo.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuestionNo.Location = new System.Drawing.Point(5, 41);
            this.txtQuestionNo.Name = "txtQuestionNo";
            this.txtQuestionNo.Size = new System.Drawing.Size(101, 29);
            this.txtQuestionNo.TabIndex = 14;
            this.toolTip1.SetToolTip(this.txtQuestionNo, "Type the question where you want to go.");
            this.txtQuestionNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuestionNo_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(-1, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(133, 19);
            this.label10.TabIndex = 12;
            this.label10.Text = "Type question no:";
            // 
            // btnGo
            // 
            this.btnGo.BackColor = System.Drawing.SystemColors.Control;
            this.btnGo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGo.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGo.Location = new System.Drawing.Point(5, 75);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(66, 27);
            this.btnGo.TabIndex = 13;
            this.btnGo.Text = "Go";
            this.toolTip1.SetToolTip(this.btnGo, "Click here to go to the question no. that you typed.");
            this.btnGo.UseVisualStyleBackColor = false;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // panel7
            // 
            this.panel7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel7.AutoScroll = true;
            this.panel7.BackColor = System.Drawing.Color.Teal;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.txtOption4);
            this.panel7.Controls.Add(this.txtOption3);
            this.panel7.Controls.Add(this.txtOption1);
            this.panel7.Controls.Add(this.txtOption2);
            this.panel7.Controls.Add(this.rdbOption4);
            this.panel7.Controls.Add(this.rdbOption2);
            this.panel7.Controls.Add(this.label8);
            this.panel7.Controls.Add(this.label6);
            this.panel7.Controls.Add(this.label5);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Controls.Add(this.rdbOption1);
            this.panel7.Controls.Add(this.rdbOption3);
            this.panel7.Location = new System.Drawing.Point(270, 315);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(811, 228);
            this.panel7.TabIndex = 11;
            this.toolTip1.SetToolTip(this.panel7, "Answers");
            // 
            // txtOption4
            // 
            this.txtOption4.Location = new System.Drawing.Point(480, 117);
            this.txtOption4.Name = "txtOption4";
            this.txtOption4.ReadOnly = true;
            this.txtOption4.Size = new System.Drawing.Size(310, 100);
            this.txtOption4.TabIndex = 21;
            this.txtOption4.Text = "";
            // 
            // txtOption3
            // 
            this.txtOption3.Location = new System.Drawing.Point(480, 8);
            this.txtOption3.Name = "txtOption3";
            this.txtOption3.ReadOnly = true;
            this.txtOption3.Size = new System.Drawing.Size(310, 100);
            this.txtOption3.TabIndex = 20;
            this.txtOption3.Text = "";
            // 
            // txtOption1
            // 
            this.txtOption1.Location = new System.Drawing.Point(60, 8);
            this.txtOption1.Name = "txtOption1";
            this.txtOption1.ReadOnly = true;
            this.txtOption1.Size = new System.Drawing.Size(310, 100);
            this.txtOption1.TabIndex = 18;
            this.txtOption1.Text = "";
            // 
            // txtOption2
            // 
            this.txtOption2.Location = new System.Drawing.Point(60, 117);
            this.txtOption2.Name = "txtOption2";
            this.txtOption2.ReadOnly = true;
            this.txtOption2.Size = new System.Drawing.Size(310, 100);
            this.txtOption2.TabIndex = 19;
            this.txtOption2.Text = "";
            // 
            // rdbOption4
            // 
            this.rdbOption4.AutoSize = true;
            this.rdbOption4.Font = new System.Drawing.Font("Cambria", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbOption4.ForeColor = System.Drawing.Color.White;
            this.rdbOption4.Location = new System.Drawing.Point(462, 152);
            this.rdbOption4.Name = "rdbOption4";
            this.rdbOption4.Size = new System.Drawing.Size(132, 25);
            this.rdbOption4.TabIndex = 3;
            this.rdbOption4.TabStop = true;
            this.rdbOption4.Text = "radioButton4";
            this.rdbOption4.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.toolTip1.SetToolTip(this.rdbOption4, "Ans. 4");
            this.rdbOption4.UseVisualStyleBackColor = true;
            // 
            // rdbOption2
            // 
            this.rdbOption2.AutoSize = true;
            this.rdbOption2.Font = new System.Drawing.Font("Cambria", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbOption2.ForeColor = System.Drawing.Color.White;
            this.rdbOption2.Location = new System.Drawing.Point(42, 152);
            this.rdbOption2.Name = "rdbOption2";
            this.rdbOption2.Size = new System.Drawing.Size(132, 25);
            this.rdbOption2.TabIndex = 1;
            this.rdbOption2.TabStop = true;
            this.rdbOption2.Text = "radioButton2";
            this.rdbOption2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.toolTip1.SetToolTip(this.rdbOption2, "Ans. 2");
            this.rdbOption2.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(431, 152);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 22);
            this.label8.TabIndex = 10;
            this.label8.Text = "4.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(11, 152);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(25, 22);
            this.label6.TabIndex = 8;
            this.label6.Text = "2.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(11, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 22);
            this.label5.TabIndex = 7;
            this.label5.Text = "1.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(431, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 22);
            this.label7.TabIndex = 9;
            this.label7.Text = "3.";
            // 
            // rdbOption1
            // 
            this.rdbOption1.AutoSize = true;
            this.rdbOption1.Font = new System.Drawing.Font("Cambria", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbOption1.ForeColor = System.Drawing.Color.White;
            this.rdbOption1.Location = new System.Drawing.Point(42, 48);
            this.rdbOption1.Name = "rdbOption1";
            this.rdbOption1.Size = new System.Drawing.Size(132, 25);
            this.rdbOption1.TabIndex = 0;
            this.rdbOption1.TabStop = true;
            this.rdbOption1.Text = "radioButton1";
            this.rdbOption1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.toolTip1.SetToolTip(this.rdbOption1, "Ans. 1");
            this.rdbOption1.UseVisualStyleBackColor = true;
            // 
            // rdbOption3
            // 
            this.rdbOption3.AutoSize = true;
            this.rdbOption3.Font = new System.Drawing.Font("Cambria", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbOption3.ForeColor = System.Drawing.Color.White;
            this.rdbOption3.Location = new System.Drawing.Point(462, 45);
            this.rdbOption3.Name = "rdbOption3";
            this.rdbOption3.Size = new System.Drawing.Size(132, 25);
            this.rdbOption3.TabIndex = 2;
            this.rdbOption3.TabStop = true;
            this.rdbOption3.Text = "radioButton3";
            this.rdbOption3.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.toolTip1.SetToolTip(this.rdbOption3, "Ans. 3");
            this.rdbOption3.UseVisualStyleBackColor = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSubmit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubmit.Font = new System.Drawing.Font("Cambria", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.ForeColor = System.Drawing.Color.Yellow;
            this.btnSubmit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSubmit.Location = new System.Drawing.Point(1092, 21);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(107, 101);
            this.btnSubmit.TabIndex = 8;
            this.btnSubmit.Text = "Click here to submit";
            this.toolTip1.SetToolTip(this.btnSubmit, "Click to submit!");
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            this.btnSubmit.MouseLeave += new System.EventHandler(this.btnSubmit_MouseLeave);
            this.btnSubmit.MouseHover += new System.EventHandler(this.btnSubmit_MouseHover);
            // 
            // lblQuestionId
            // 
            this.lblQuestionId.BackColor = System.Drawing.Color.Transparent;
            this.lblQuestionId.ForeColor = System.Drawing.Color.SteelBlue;
            this.lblQuestionId.Location = new System.Drawing.Point(3, 10);
            this.lblQuestionId.Name = "lblQuestionId";
            this.lblQuestionId.Size = new System.Drawing.Size(139, 93);
            this.lblQuestionId.TabIndex = 8;
            this.lblQuestionId.Text = "label9";
            // 
            // lblSn
            // 
            this.lblSn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSn.BackColor = System.Drawing.Color.Green;
            this.lblSn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSn.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblSn.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold);
            this.lblSn.ForeColor = System.Drawing.Color.White;
            this.lblSn.Location = new System.Drawing.Point(164, 46);
            this.lblSn.Name = "lblSn";
            this.lblSn.Size = new System.Drawing.Size(86, 76);
            this.lblSn.TabIndex = 10;
            this.lblSn.Text = "QNo.";
            this.lblSn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.lblSn, "Question no.");
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Font = new System.Drawing.Font("Cambria", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel5.Location = new System.Drawing.Point(264, 310);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(822, 237);
            this.panel5.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(174, 345);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 23);
            this.label4.TabIndex = 7;
            this.label4.Text = "Answer:";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(160, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Question:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel3.BackgroundImage = global::EntranceExam.Properties.Resources.background;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.txtTime);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1276, 85);
            this.panel3.TabIndex = 10;
            // 
            // txtTime
            // 
            this.txtTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTime.BackColor = System.Drawing.Color.Green;
            this.txtTime.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtTime.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTime.ForeColor = System.Drawing.Color.White;
            this.txtTime.Location = new System.Drawing.Point(649, 43);
            this.txtTime.Multiline = true;
            this.txtTime.Name = "txtTime";
            this.txtTime.ReadOnly = true;
            this.txtTime.Size = new System.Drawing.Size(151, 31);
            this.txtTime.TabIndex = 9;
            this.txtTime.TabStop = false;
            this.txtTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.toolTip1.SetToolTip(this.txtTime, "Remaining time");
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(541, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 26);
            this.label9.TabIndex = 8;
            this.label9.Text = "Time left:";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label1.Font = new System.Drawing.Font("Cambria", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SteelBlue;
            this.label1.Location = new System.Drawing.Point(463, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(441, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Entrance Examination - 2015";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.BackgroundImage = global::EntranceExam.Properties.Resources.background;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.txtRecordPosition);
            this.panel2.Controls.Add(this.btnMovePrevious);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.btnMoveNext);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 655);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1276, 61);
            this.panel2.TabIndex = 0;
            // 
            // txtRecordPosition
            // 
            this.txtRecordPosition.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRecordPosition.BackColor = System.Drawing.Color.Green;
            this.txtRecordPosition.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtRecordPosition.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRecordPosition.ForeColor = System.Drawing.Color.White;
            this.txtRecordPosition.Location = new System.Drawing.Point(600, 15);
            this.txtRecordPosition.Multiline = true;
            this.txtRecordPosition.Name = "txtRecordPosition";
            this.txtRecordPosition.ReadOnly = true;
            this.txtRecordPosition.Size = new System.Drawing.Size(158, 31);
            this.txtRecordPosition.TabIndex = 7;
            this.txtRecordPosition.TabStop = false;
            this.txtRecordPosition.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.toolTip1.SetToolTip(this.txtRecordPosition, "Current question out of Total question");
            // 
            // btnMovePrevious
            // 
            this.btnMovePrevious.BackColor = System.Drawing.SystemColors.Control;
            this.btnMovePrevious.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMovePrevious.Font = new System.Drawing.Font("Cambria", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMovePrevious.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMovePrevious.Location = new System.Drawing.Point(6, 13);
            this.btnMovePrevious.Name = "btnMovePrevious";
            this.btnMovePrevious.Size = new System.Drawing.Size(115, 38);
            this.btnMovePrevious.TabIndex = 1;
            this.btnMovePrevious.Text = "Previous";
            this.toolTip1.SetToolTip(this.btnMovePrevious, "Click to view previous question.");
            this.btnMovePrevious.UseVisualStyleBackColor = false;
            this.btnMovePrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(488, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "Question :";
            // 
            // btnMoveNext
            // 
            this.btnMoveNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMoveNext.BackColor = System.Drawing.SystemColors.Control;
            this.btnMoveNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMoveNext.Font = new System.Drawing.Font("Cambria", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMoveNext.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMoveNext.Location = new System.Drawing.Point(1149, 13);
            this.btnMoveNext.Name = "btnMoveNext";
            this.btnMoveNext.Size = new System.Drawing.Size(115, 38);
            this.btnMoveNext.TabIndex = 0;
            this.btnMoveNext.Text = "Next";
            this.toolTip1.SetToolTip(this.btnMoveNext, "Click to view next question.");
            this.btnMoveNext.UseVisualStyleBackColor = false;
            this.btnMoveNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblSection
            // 
            this.lblSection.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSection.BackColor = System.Drawing.Color.Green;
            this.lblSection.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSection.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblSection.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold);
            this.lblSection.ForeColor = System.Drawing.Color.White;
            this.lblSection.Location = new System.Drawing.Point(10, 46);
            this.lblSection.Name = "lblSection";
            this.lblSection.Size = new System.Drawing.Size(148, 35);
            this.lblSection.TabIndex = 18;
            this.lblSection.Text = "lblSection";
            this.lblSection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.lblSection, "Question no.");
            // 
            // lblMarks
            // 
            this.lblMarks.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMarks.BackColor = System.Drawing.Color.Green;
            this.lblMarks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMarks.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblMarks.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold);
            this.lblMarks.ForeColor = System.Drawing.Color.White;
            this.lblMarks.Location = new System.Drawing.Point(10, 87);
            this.lblMarks.Name = "lblMarks";
            this.lblMarks.Size = new System.Drawing.Size(148, 35);
            this.lblMarks.TabIndex = 19;
            this.lblMarks.Text = "lblMarks";
            this.lblMarks.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.lblMarks, "Question no.");
            // 
            // FormExamTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1278, 718);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1280, 720);
            this.Name = "FormExamTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Exam";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormExamTest_FormClosing);
            this.Load += new System.EventHandler(this.FormExamTest_Load);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.grpGoTo.ResumeLayout(false);
            this.grpGoTo.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnMovePrevious;
        private System.Windows.Forms.Button btnMoveNext;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton rdbOption4;
        private System.Windows.Forms.RadioButton rdbOption3;
        private System.Windows.Forms.RadioButton rdbOption2;
        private System.Windows.Forms.RadioButton rdbOption1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRecordPosition;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblQuestionId;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblSn;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.GroupBox grpGoTo;
        private System.Windows.Forms.TextBox txtQuestionNo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.RichTextBox txtQuestion;
        private System.Windows.Forms.RichTextBox txtOption1;
        private System.Windows.Forms.RichTextBox txtOption2;
        private System.Windows.Forms.RichTextBox txtOption3;
        private System.Windows.Forms.RichTextBox txtOption4;
        private System.Windows.Forms.Label lblMarks;
        private System.Windows.Forms.Label lblSection;
    }
}