﻿namespace EntranceExam
{
    partial class FormQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormQuestion));
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.createQuestion2 = new ControlLibrary.CreateQuestion();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.viewQuestion2 = new ControlLibrary.ViewQuestion();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.createQuestion1 = new ControlLibrary.CreateQuestion();
            this.viewQuestion1 = new ControlLibrary.ViewQuestion();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ImageList = this.imageList1;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1251, 733);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackgroundImage = global::EntranceExam.Properties.Resources.background;
            this.tabPage1.Controls.Add(this.createQuestion2);
            this.tabPage1.ImageIndex = 0;
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1019, 706);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Create";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // createQuestion2
            // 
            this.createQuestion2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.createQuestion2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.createQuestion2.Location = new System.Drawing.Point(3, 3);
            this.createQuestion2.Name = "createQuestion2";
            this.createQuestion2.Size = new System.Drawing.Size(1013, 700);
            this.createQuestion2.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackgroundImage = global::EntranceExam.Properties.Resources.background;
            this.tabPage2.Controls.Add(this.viewQuestion2);
            this.tabPage2.ImageIndex = 1;
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1243, 706);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "View & Modify";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // viewQuestion2
            // 
            this.viewQuestion2.AutoScroll = true;
            this.viewQuestion2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.viewQuestion2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.viewQuestion2.Location = new System.Drawing.Point(3, 3);
            this.viewQuestion2.Name = "viewQuestion2";
            this.viewQuestion2.Size = new System.Drawing.Size(1237, 700);
            this.viewQuestion2.TabIndex = 0;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "1431586047_698913-icon-81-document-add-24.png");
            this.imageList1.Images.SetKeyName(1, "windows_view_icon [www.imagesplitter.net].png");
            // 
            // createQuestion1
            // 
            this.createQuestion1.Location = new System.Drawing.Point(0, 0);
            this.createQuestion1.Name = "createQuestion1";
            this.createQuestion1.Size = new System.Drawing.Size(542, 440);
            this.createQuestion1.TabIndex = 0;
            // 
            // viewQuestion1
            // 
            this.viewQuestion1.AutoScroll = true;
            this.viewQuestion1.Location = new System.Drawing.Point(0, 0);
            this.viewQuestion1.Name = "viewQuestion1";
            this.viewQuestion1.Size = new System.Drawing.Size(1010, 703);
            this.viewQuestion1.TabIndex = 0;
            // 
            // FormQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1251, 733);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormQuestion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Question";
            this.Load += new System.EventHandler(this.FormQuestion_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private ControlLibrary.CreateQuestion createQuestion1;
        private ControlLibrary.ViewQuestion viewQuestion1;
        private System.Windows.Forms.ImageList imageList1;
        private ControlLibrary.CreateQuestion createQuestion2;
        private ControlLibrary.ViewQuestion viewQuestion2;
    }
}