﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EntranceExam
{
    public partial class FormQuestion : Form
    {        
        public FormQuestion()
        {
            InitializeComponent();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = tabControl1.SelectedIndex;
            if (i == 0)
                this.Size = new Size(571, 508);
            else
                this.Size = new Size(1267, 772);

        }

        private void FormQuestion_Load(object sender, EventArgs e)
        {
            this.Size = new Size(571, 508);
        }

    }
}