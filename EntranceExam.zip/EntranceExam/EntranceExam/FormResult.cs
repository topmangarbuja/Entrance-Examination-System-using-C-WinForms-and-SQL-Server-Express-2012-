﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using ClassLibrary;

namespace EntranceExam
{
    public partial class FormResult : Form
    {
        private DataAccess dataAccess = new DataAccess();
        private DataTable objDataTable;
        public FormResult()
        {
            InitializeComponent();
        }

        private void btnViewResult_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM(SELECT U.Uname As Username, FirstName + ' ' + LastName As [Full name], SUM(Marks) As [Total marks] " +
                          "FROM Question As Q " +
                          "INNER JOIN dbo.SelectedAnswer As SA ON SA.QuestionId=Q.QuestionId " +
                          "INNER JOIN dbo.Users As U ON SA.Uname=U.Uname " +
                          "WHERE Q.AnswerText=SA.AnswerText " +
                          "GROUP BY U.Uname,FirstName + ' ' + LastName) As D " +
                          "ORDER BY [Total marks] DESC, [Full name];";

            //string query = "SELECT Uname,QuestionId,CStr(Answer) FROM SelectedAnswer;";


            dataAccess.RunQueryFillDataSet(query);


            if (dataAccess.errRunQueryFillDataSet != "")
            {
                //Show error message
                MessageBox.Show(dataAccess.errRunQueryFillDataSet, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //Set variable to default
                dataAccess.errRunQueryFillDataSet = "";
            }
            else
            {
                objDataTable = new DataTable();
                objDataTable = dataAccess.dsRunQuery.Tables[0];
                GlobalAccess.dtResult = dataAccess.AutoNumberedTable(objDataTable);
                grdResult.DataSource = objDataTable;
                grdResult.Columns[0].Frozen = true;

                if (grdResult.Rows.Count>0)
                {
                    btnGetReport.Enabled = true;
                }
                else
                {
                    btnGetReport.Enabled = false;
                }
            }
        }

        private void btnGetReport_Click(object sender, EventArgs e)
        {
            FormReport formReport = new FormReport();
            formReport.ShowDialog();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void FormResult_Load(object sender, EventArgs e)
        {
            this.Size = new Size(556, 643);
            btnGetReport.Enabled = false;
            btnDeleteResult.Enabled = false;
            getUsernameForComboBox();
        }





        private void btnDeleteResult_Click(object sender, EventArgs e)
        {
            string strUsername = cboUsername.Text.ToString();

            if (MessageBox.Show("Are you sure want to delete the result of " + strUsername +"?",this.Text, MessageBoxButtons.YesNo,
                MessageBoxIcon.Question)==DialogResult.Yes)
            {
                SqlCommand command = new SqlCommand();
                command.CommandText = "DELETE FROM SelectedAnswer " +
                    "WHERE Uname=@username;";
                command.Parameters.AddWithValue("@username", strUsername);
                dataAccess.RunQuery(command);

                if (dataAccess.errRunQuery != "")
                {
                    MessageBox.Show(dataAccess.errRunQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    //Set the variable to default
                    dataAccess.errRunQuery = "";
                }
                else
                {
                    MessageBox.Show("The result of the " + strUsername + " has been successfully deleted.", "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }

                getUsernameForComboBox();
            }
           
        }


        private void getUsernameForComboBox()
        {            
            string query = "SELECT DISTINCT Uname FROM dbo.SelectedAnswer;";
            
            dataAccess.RunQueryFillDataSet(query);            
            if (dataAccess.errRunQueryFillDataSet != "")
            {
                //Show error message
                MessageBox.Show(dataAccess.errRunQueryFillDataSet, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //Set variable to default
                dataAccess.errRunQueryFillDataSet = "";
            }
            else
            {
                objDataTable = new DataTable();
                objDataTable = dataAccess.dsRunQuery.Tables[0];
                cboUsername.DataSource = objDataTable;
                cboUsername.DisplayMember = "Uname";                

                if(cboUsername.Items.Count > 0)
                {
                    btnDeleteResult.Enabled = true;
                }
                else
                {
                    btnDeleteResult.Enabled = false;
                }
            }

        }

        private void cboUsername_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnDeleteResult.Enabled = true;
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(tabControl1.SelectedIndex==0)
            {
                this.Size = new Size(556, 643);
            }
            else if(tabControl1.SelectedIndex==1)
            {
                this.Size = new Size(377, 189);
            }
        }
    }
}
