﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using ClassLibrary;

namespace EntranceExam
{
    public partial class FormMain : Form
    {
        private DataAccess dataAccess;
        private DataSet ds = new DataSet();
        private DataTable dt = new DataTable();
        private Random rdm = new Random();
        private Random rdm0 = new Random();
        private Random rdm1 = new Random();
        private Random rdm2 = new Random();
        private Random rdm3 = new Random();
        private DataTable dtQuestion;
        //private DataSet ds1 = new DataSet();

        private int intCount = 0;

        public FormMain()
        {
            InitializeComponent();
            timer1.Enabled = true;
        }

        private void userToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUser formUser = new FormUser();
            formUser.Show();
        }

        private void questionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormQuestion formQuestion = new FormQuestion();
            formQuestion.Show();
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            /*
            if (MessageBox.Show("Are you sure want to close the application?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                e.Cancel = false;

                //this.Close();
            }                
            else
            {
                e.Cancel = true;
            }
             */
            Application.Exit();
            
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            string strUsername=GlobalAccess.username;
            toolStripStatusUsername.Text = strUsername.ToString().ToUpper();
            
            if ((strUsername.ToLower()).StartsWith("admin") == true)
            {
                btnClickHere.Visible = false;
            }  
        }

        private void timer1_Tick(object sender, EventArgs e)
        {            
            if (intCount==0)
            {
                btnClickHere.ForeColor = Color.Orange;
                intCount+=1;
            }            
            else if(intCount==1)
            {
                btnClickHere.ForeColor = Color.Yellow;
                intCount += 1;
            }
            else
            {
                btnClickHere.ForeColor = Color.White;
                intCount = 0;
            }


        }

        private void btnClickHere_MouseEnter(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void btnClickHere_MouseLeave(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClickHere_Click(object sender, EventArgs e)
        {         

            GetTime();

            dataAccess = new DataAccess();

            #region Try1
            timer1.Enabled = false;

            String query = "SELECT QuestionId, Question,AnswerRtf As CorrectAnswer,Option1,Option2,Option3,Marks FROM dbo.Question ORDER BY Marks,QuestionId;";
            dataAccess.RunQueryFillDataSet(query);


            if (dataAccess.errRunQueryFillDataSet != "")
            {
                //Show error message
                MessageBox.Show(dataAccess.errRunQueryFillDataSet, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Set variable to default
                dataAccess.errRunQueryFillDataSet = "";
            }
            else
            {
                dt = dataAccess.AutoNumberedTable(dataAccess.dsRunQuery.Tables[0]);

                dtQuestion = new DataTable("Question");
                dtQuestion.Columns.Add("Sn", typeof(int));
                dtQuestion.Columns.Add("QuestionId", typeof(int));
                dtQuestion.Columns.Add("Question", typeof(String));
                dtQuestion.Columns.Add("a", typeof(String));
                dtQuestion.Columns.Add("b", typeof(String));
                dtQuestion.Columns.Add("c", typeof(String));
                dtQuestion.Columns.Add("d", typeof(String));
                dtQuestion.Columns.Add("Marks", typeof(String));

                //Go through each row in table
                foreach (DataRow item in dt.Rows)
                {
                    int intSn = Convert.ToInt32(item[0].ToString());
                    int intQuestionId = Convert.ToInt32(item["QuestionId"].ToString());
                    String strQuestion = item["Question"].ToString();
                    String strCorrectAnswer = item["CorrectAnswer"].ToString();
                    String opt1 = item["Option1"].ToString();
                    String opt2 = item["Option2"].ToString();
                    String opt3 = item["Option3"].ToString();
                    String a = "";
                    String b = "";
                    String c = "";
                    String d = "";
                    int intMarks = Convert.ToInt32(item["Marks"].ToString());

                    //Create a random object to set value for a,b,c,d variable to insert into a  table                    
                    int intRandom = rdm.Next(0, 3);

                    switch (intRandom)
                    {
                        case 0:
                            a = strCorrectAnswer;

                            //Create a random object to set value for b,c,d variable to insert into a  table
                            
                            int intRandom0 = rdm.Next(1, 4);
                            if (intRandom0 == 1)
                            {
                                b = opt1;
                                c = opt2;
                                d = opt3;
                            }
                            else if (intRandom0 == 2)
                            {
                                b = opt3;
                                c = opt2;
                                d = opt1;
                            }
                            else if (intRandom0 == 3)
                            {
                                b = opt1;
                                c = opt3;
                                d = opt2;
                            }
                            break;
                        case 1:
                            a = opt1;

                            //Create a random object to set value for a,b,c,d variable to insert into a  table
                            
                            int intRandom1 = rdm.Next(1, 4);
                            if (intRandom1 == 1)
                            {
                                b = strCorrectAnswer;
                                c = opt2;
                                d = opt3;
                            }
                            else if (intRandom1 == 2)
                            {
                                b = opt3;
                                c = strCorrectAnswer;
                                d = opt2;
                            }
                            else if (intRandom1 == 3)
                            {
                                b = opt2;
                                c = opt3;
                                d = strCorrectAnswer;
                            }
                            break;
                        case 2:
                            a = opt2;

                            //Create a random object to set value for a,b,c,d variable to insert into a  table
                            
                            int intRandom2 = rdm.Next(1, 4);
                            if (intRandom2 == 1)
                            {
                                b = strCorrectAnswer;
                                c = opt1;
                                d = opt3;
                            }
                            else if (intRandom2 == 2)
                            {
                                b = opt3;
                                c = strCorrectAnswer;
                                d = opt1;
                            }
                            else if (intRandom2 == 3)
                            {
                                b = opt1;
                                c = opt3;
                                d = strCorrectAnswer;
                            }
                            break;
                        case 3:
                            a = opt3;

                            //Create a random object to set value for a,b,c,d variable to insert into a  table
                            
                            int intRandom3 = rdm.Next(1, 4);
                            if (intRandom3 == 1)
                            {
                                b = strCorrectAnswer;
                                c = opt1;
                                d = opt2;
                            }
                            else if (intRandom3 == 2)
                            {
                                b = opt2;
                                c = strCorrectAnswer;
                                d = opt1;
                            }
                            else if (intRandom3 == 3)
                            {
                                b = opt1;
                                c = opt2;
                                d = strCorrectAnswer;
                            }
                            break;
                    }
                    //MessageBox.Show(a);


                    DataRow drQuestion = dtQuestion.NewRow();
                    drQuestion["Sn"] = intSn;
                    drQuestion["QuestionId"] = intQuestionId;
                    drQuestion["Question"] = strQuestion;
                    drQuestion["a"] = a;
                    drQuestion["b"] = b;
                    drQuestion["c"] = c;
                    drQuestion["d"] = d;
                    drQuestion["Marks"] = intMarks;

                    dtQuestion.Rows.Add(drQuestion);
                }

                //txtQuestion.Text= dt.Rows.Count
                //FillDataGridView();
                GlobalAccess.dt = dtQuestion;
            }
            //Clear the fields
            //Clear();   

            StringBuilder objStringBuilder = new StringBuilder();            
            objStringBuilder.AppendLine("Note:");
            objStringBuilder.AppendLine("i.  There are total "+ dt.Rows.Count + " questions.");
            objStringBuilder.AppendLine("ii. The allocated time for the examination is: " + GlobalAccess.time +" minutes. Attempt all of the questions within that time.");
            objStringBuilder.AppendLine(String.Empty);
            objStringBuilder.AppendLine("Click OK to start the examination!");
            MessageBox.Show(objStringBuilder.ToString(), this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);          

            this.Hide();
            FormExamTest formExamTest = new FormExamTest();
            formExamTest.Show();
            
            #endregion           

        }

        private void viewResultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormResult formResult = new FormResult();
            formResult.Show();
        }


        private void GetTime()
        {
            dataAccess = new DataAccess();
            SqlCommand command = new SqlCommand();
            command.CommandText = "SELECT period FROM dbo.Duration;";
            dataAccess.SelectQuery(command);

            if (dataAccess.errSelectQuery != "")
            {
                MessageBox.Show(dataAccess.errSelectQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dataAccess.errSelectQuery = "";

                MessageBox.Show("Try again, please!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                GlobalAccess.time = dataAccess.intNumber;
            }

        }

        private void fileToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            string strUsername=GlobalAccess.username.ToLower();
            if (!(strUsername).StartsWith("admin")==true)
            {
                createToolStripMenuItem.Visible = false;
                viewResultToolStripMenuItem.Visible = false;
            }           
        }

        private void timeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTime formTime = new FormTime();
            formTime.ShowDialog();
        }
    }
}

