﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EntranceExam
{
    public partial class FormUser : Form
    {
        public FormUser()
        {
            InitializeComponent();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i=tabControl1.SelectedIndex;

            if (i == 0)
                this.Size = new Size(389, 284);
            else
                this.Size = new Size(595, 659);
        }

        private void FormUser_Load(object sender, EventArgs e)
        {
            this.Size = new Size(389, 284);
        }
    }
}
