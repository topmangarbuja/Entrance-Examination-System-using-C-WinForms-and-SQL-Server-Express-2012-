﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using ClassLibrary;

namespace EntranceExam
{
    public partial class FormExamTest : Form
    {
        private DataAccess dataAccess;
        //private DataSet ds;
        private DataTable dt;
        private DataView objDataView = new DataView();
        private CurrencyManager objCurrencyManager;
        private Dictionary<int, int> objDictionaryAnswer = new Dictionary<int, int>();
        private String strUsername = GlobalAccess.username;        
        private Boolean blnIsPrevious = false;
        private RichTextBox strAnswerMemo;

        private int intCurrentRow = 0;
        
        
        
        Timer timer = new Timer { Interval = 1000 };
        DateTime startTime = DateTime.Now;
        int intTime = GlobalAccess.time;
        TimeSpan ts;

        Int16 intCount = 0;

        public FormExamTest()
        {
            InitializeComponent();            
            txtTime.Text = TimeSpan.FromMinutes(intTime).ToString();            
            timer.Tick += new EventHandler(timer_Tick);
        }

        void timer_Tick(object sender,EventArgs e)
        {
            ts = TimeSpan.FromMinutes(intTime) - (DateTime.Now - startTime);
            txtTime.Text = ts.ToString("hh\\:mm\\:ss");

            if (ts.Hours==0 && ts.Minutes == 2 && ts.Seconds == 0)
            {
                txtTime.ForeColor = Color.Orange;
            }
            else if (ts.Hours == 0 && ts.Minutes == 1 && ts.Seconds == 0)
            {
                txtTime.ForeColor = Color.Red;
            }
            if (ts.Hours == 0 && ts.Minutes == 0 && ts.Seconds == 0)
            {
                timer.Stop();

                StringBuilder objStringBuilder = new StringBuilder();                
                    objStringBuilder.AppendLine("Time's up!");
                    objStringBuilder.AppendLine("Thank you for the Entrance Exam.");
                    objStringBuilder.AppendLine(string.Empty);                    
                    objStringBuilder.AppendLine("Best of luck for the Result.");                                                      
                    objStringBuilder.AppendLine("Click OK to continue.");
                    MessageBox.Show(objStringBuilder.ToString(), this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Application.Exit();
            }

            if (btnSubmit.Visible)
            {
                if(intCount==0)
                {
                    btnSubmit.ForeColor = Color.Yellow;
                    intCount += 1;
                }
                else if(intCount==1)
                {
                    btnSubmit.ForeColor = Color.White;
                    intCount = 0;
                }
                

            }
        }

        private void FormExamTest_Load(object sender, EventArgs e)
        {
            FillDataTableAndView();
            BindFields();
            ShowPosition();
            btnSubmit.Visible = false;
            grpGoTo.Visible = false;
            

            //Call method to check whether to enable Previous or Next button
            Check();

            timer.Start();
        }       

        private void FillDataTableAndView()
        {            
            dt = new DataTable("Question");
            dt.Columns.Add("Sn", typeof(int));
            dt.Columns.Add("QuestionId", typeof(int));
            dt.Columns.Add("Question", typeof(String));
            dt.Columns.Add("a", typeof(String));
            dt.Columns.Add("b", typeof(String));
            dt.Columns.Add("c", typeof(String));
            dt.Columns.Add("d", typeof(String));
            dt.Columns.Add("Marks", typeof(int));

            dt=GlobalAccess.dt;
            objDataView = new DataView(dt);
            objCurrencyManager = ((CurrencyManager)this.BindingContext[objDataView]);
        }

        private void BindFields()
        {             

            //Clear any previous bindings
            lblSn.DataBindings.Clear();
            lblQuestionId.DataBindings.Clear();
            txtQuestion.DataBindings.Clear();
            txtOption1.DataBindings.Clear();            
            txtOption2.DataBindings.Clear();
            txtOption3.DataBindings.Clear();
            txtOption4.DataBindings.Clear();

            //Add new bindings to the DataView object..
            lblSn.DataBindings.Add("Text", objDataView, "Sn");
            lblQuestionId.DataBindings.Add("Text", objDataView, "QuestionId");
            txtQuestion.DataBindings.Add("Rtf", objDataView, "Question");
            txtOption1.DataBindings.Add("Rtf", objDataView, "a");
            txtOption2.DataBindings.Add("Rtf", objDataView, "b");
            txtOption3.DataBindings.Add("Rtf", objDataView, "c");
            txtOption4.DataBindings.Add("Rtf", objDataView, "d");


            //Get the rowNumber where the question of Marks:2 get starts from
            foreach(DataRow item in dt.Rows)
            {
                int intMarks = Convert.ToInt32(item["Marks"].ToString());    
                if(intMarks==2)
                {
                    return;
                }
                intCurrentRow++;
            }
            
                        
            
        }

        private void ShowPosition()
        {
            //Display the current position and the number of records
            txtRecordPosition.Text = objCurrencyManager.Position + 1 + "    of    " + objCurrencyManager.Count;
            
            //Update the Secion and Marks label according to the Marks allocated from the question
            if(objCurrencyManager.Position<intCurrentRow)
            {
                lblSection.Text="Section I";
                lblMarks.Text="1 Marks";
            }
            else
            {
                lblSection.Text = "Section II";
                lblMarks.Text = "2 Marks";
            }
        
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (rdbOption1.Checked == true || rdbOption2.Checked == true || rdbOption3.Checked == true || rdbOption4.Checked == true)
            {

                int intKey = Convert.ToInt32(lblSn.Text.ToString());
                //Int variable to get which of the RadioButton is selected or not anyone is selected
                int intSelect;
                if (rdbOption1.Checked == true)
                    intSelect = 1;
                else if (rdbOption2.Checked == true)
                    intSelect = 2;
                else if (rdbOption3.Checked == true)
                    intSelect = 3;
                else if (rdbOption4.Checked == true)
                    intSelect = 4;
                else
                    intSelect = 0;                          
                       

                //if the key already exist then update the value of the key, if not exists then add the key and its value
                if (objDictionaryAnswer.ContainsKey(intKey))
                {
                    if (objDictionaryAnswer[intKey] != intSelect)
                    {
                        blnIsPrevious = true;
                        DatabaseManipulation();

                        //Call method to check whether to enable Previous or Next button
                        Check();
                        return;
                    }
                }
                else
                {
                    blnIsPrevious = true;
                    DatabaseManipulation();

                    //Call method to check whether to enable Previous or Next button
                    Check();
                    return;
                }
                
            }           
                AddToDictionary(Convert.ToInt32(lblSn.Text.ToString()));
                CheckInDictionary(Convert.ToInt32(lblSn.Text.ToString()) - 1);

                objCurrencyManager.Position -= 1;
                ShowPosition();

                //Call method to check whether to enable Previous or Next button
                Check();
            
        }

        private void btnNext_Click(object sender, EventArgs e)
        {                                                       

            if (rdbOption1.Checked==true||rdbOption2.Checked==true || rdbOption3.Checked==true || rdbOption4.Checked==true)
            {
                int intKey = Convert.ToInt32(lblSn.Text.ToString());
                //Int variable to get which of the RadioButton is selected or not anyone is selected
                int intSelect;
                if (rdbOption1.Checked == true)
                    intSelect = 1;
                else if (rdbOption2.Checked == true)
                    intSelect = 2;
                else if (rdbOption3.Checked == true)
                    intSelect = 3;
                else if (rdbOption4.Checked == true)
                    intSelect = 4;
                else
                    intSelect = 0;

                //if the key already exist then update the value of the key, if not exists then add the key and its value
                if (objDictionaryAnswer.ContainsKey(intKey))
                {
                    if (objDictionaryAnswer[intKey] != intSelect)
                    {
                        blnIsPrevious = false;
                        DatabaseManipulation();

                        //Call method to check whether to enable Previous or Next button
                        Check();
                        return;
                    }
                }
                else
                {
                    blnIsPrevious = false;
                    DatabaseManipulation();

                    //Call method to check whether to enable Previous or Next button
                    Check();
                    return;
                }
                
            }

            
                AddToDictionary(Convert.ToInt32(lblSn.Text.ToString()));
                CheckInDictionary(Convert.ToInt32(lblSn.Text.ToString()) + 1);

                objCurrencyManager.Position += 1;
                ShowPosition();           

            //Call method to check whether to enable Previous or Next button
            Check();         
           
        }


        #region DatabaseManipulation,DatabaseManipulationForSubmit,InsertData,UpdateData,GetAnswer
        private void DatabaseManipulation()
        {
            dataAccess = new DataAccess();

            //Process to check whether already the user and the answer for the Question is selected or not
            int intQuestionId = Convert.ToInt32(lblQuestionId.Text.ToString());
            String query = "SELECT Uname FROM SelectedAnswer " +
                "WHERE Uname='" + strUsername + "' " +
                "AND QuestionId=" + intQuestionId + ";";
            dataAccess.RunQueryFillDataSet(query);

            if (dataAccess.errRunQueryFillDataSet != "")
            {
                //Show error message
                MessageBox.Show(dataAccess.errRunQueryFillDataSet, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //Set variable to default
                dataAccess.errRunQueryFillDataSet = "";
            }
            else
            {
                if (dataAccess.dsRunQuery.Tables[0].Rows.Count == 1)
                {
                    //if username and the answer already exist, Update the table
                    if (UpdateData() == true)
                    {
                        AddToDictionary(Convert.ToInt32(lblSn.Text.ToString()));     

                        //Check if the Previous or Next button is clicked
                        if (blnIsPrevious==true)
                        {
                            CheckInDictionary(Convert.ToInt32(lblSn.Text.ToString()) - 1);
                            objCurrencyManager.Position -= 1;
                        }                        
                        else
                        {
                            CheckInDictionary(Convert.ToInt32(lblSn.Text.ToString()) + 1);
                            objCurrencyManager.Position += 1;
                        }
                            

                        
                        ShowPosition();
                    }
                    else
                    {
                        //Something gone wrong.
                        MessageBox.Show("Something gone wrong.Pleas try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    //if not username and the answer exist, Insert into the table                    
                    if (InsertData() == true)
                    {
                        AddToDictionary(Convert.ToInt32(lblSn.Text.ToString()));
                        //Check if the Previous or Next button is clicked
                        if (blnIsPrevious == true)
                        {
                            CheckInDictionary(Convert.ToInt32(lblSn.Text.ToString()) - 1);
                            objCurrencyManager.Position -= 1;
                        }
                        else
                        {
                            CheckInDictionary(Convert.ToInt32(lblSn.Text.ToString()) + 1);
                            objCurrencyManager.Position += 1;
                        }
                        
                        ShowPosition();
                    }
                    else
                    {
                        //Something gone wrong.
                        MessageBox.Show("Something gone wrong.Pleas try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }
            }           
            
        }
              
        //Method--to submit the selected answer of the question at a certain position of the question in the Form
        private void DatabaseManipulationForSubmit()
        {
            dataAccess = new DataAccess();
            //Process to check whether already the user and the answer for the Question is selected or not
            int intQuestionId = Convert.ToInt32(lblQuestionId.Text.ToString());
            String query = "SELECT Uname FROM dbo.SelectedAnswer " +
                "WHERE Uname='" + strUsername + "' " +
                "AND QuestionId=" + intQuestionId + ";";
            dataAccess.RunQueryFillDataSet(query);

            if (dataAccess.errRunQueryFillDataSet != "")
            {
                //Show error message
                MessageBox.Show(dataAccess.errRunQueryFillDataSet, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //Set variable to default
                dataAccess.errRunQueryFillDataSet = "";
            }
            else
            {
                if (dataAccess.dsRunQuery.Tables[0].Rows.Count == 1)
                {
                    //if username and the answer already exist, Update the table
                    if (UpdateData() == true)
                    {
                        AddToDictionary(Convert.ToInt32(lblSn.Text.ToString()));
                         
                    }
                    else
                    {
                        //Something gone wrong.
                        MessageBox.Show("Something gone wrong.Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    //if not username and the answer exist, Insert into the table                    
                    if (InsertData() == true)
                    {
                        AddToDictionary(Convert.ToInt32(lblSn.Text.ToString()));
                                                
                    }
                    else
                    {
                        //Something gone wrong.
                        MessageBox.Show("Something gone wrong.Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }
            }

        }

        //Method--to insert the selected answer of the corresponding question and the user
        private bool InsertData()
        {
            dataAccess = new DataAccess();

            //Get the selected answer
            GetAnswer();

            SqlCommand command = new SqlCommand();
            command.CommandText = "INSERT INTO dbo.SelectedAnswer(Uname,QuestionId,AnswerRtf,AnswerText) VALUES(@username,@id,@answerRtf,@answerText);";
            command.Parameters.AddWithValue("@username", strUsername);
            command.Parameters.AddWithValue("@id", lblQuestionId.Text);
            command.Parameters.AddWithValue("@answerRtf",strAnswerMemo.Rtf);
            command.Parameters.AddWithValue("@answerText", strAnswerMemo.Text);
            
            dataAccess.RunQuery(command);

            if (dataAccess.errRunQuery != "")
            {
                //Show error message
                MessageBox.Show(dataAccess.errRunQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Set variable to default
                dataAccess.errRunQuery = "";

                return false;
            }
            else
            {
                return true;
            }
        }

        //Method--to update the selected answer of the corresponding question and the user
        private bool UpdateData()
        {
            dataAccess = new DataAccess();

            //Get the selected answer
            GetAnswer();
            int intQuestionId = Convert.ToInt32(lblQuestionId.Text.ToString());
            SqlCommand command = new SqlCommand();
            command.CommandText = "UPDATE dbo.SelectedAnswer SET AnswerRtf=@answerRtf,AnswerText=@answerText " +
                "WHERE Uname='" + strUsername + "' " +
                "AND QuestionId=" + intQuestionId + ";";
            command.Parameters.AddWithValue("@answerRtf", strAnswerMemo.Rtf);
            command.Parameters.AddWithValue("@answerText", strAnswerMemo.Text);

            dataAccess.RunQuery(command);

            if (dataAccess.errRunQuery != "")
            {
                //Show error message
                MessageBox.Show(dataAccess.errRunQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Set variable to default
                dataAccess.errRunQuery = "";

                return false;
            }
            else
            {
                //Show error message
                //MessageBox.Show("Data saved successfully!", "Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //Clear the fields
                //Clear();
                return true;
            }
        }

        //Method--to get the selected answer of the corresponding question
        private void GetAnswer()
        {
            strAnswerMemo = new RichTextBox();
            
            //Get the selected answer
            if (rdbOption1.Checked == true)
            {
                strAnswerMemo.Rtf = txtOption1.Rtf;
                strAnswerMemo.Text = txtOption1.Text;                
            }                
            else if (rdbOption2.Checked == true)
            {
                strAnswerMemo.Rtf = txtOption2.Rtf;
                strAnswerMemo.Text = txtOption2.Text;
            }                
            else if (rdbOption3.Checked == true)
            {
                strAnswerMemo.Rtf = txtOption3.Rtf;
                strAnswerMemo.Text = txtOption3.Text;
            }                
            else if (rdbOption4.Checked == true)
            {
                strAnswerMemo.Rtf = txtOption4.Rtf;
               strAnswerMemo.Text=txtOption4.Text;
            }                
            else
            {
                strAnswerMemo.Rtf = "";
                strAnswerMemo.Text="";
            }
                
        }
#endregion

       





        //Method--to add the serialNumber and Selection of radioButton as int value in the Dictionary variable
        private void AddToDictionary(int intKey)
        {            
            //Int variable to get which of the RadioButton is selected or not anyone is selected
            int intSelect;
            if (rdbOption1.Checked == true)
                intSelect = 1;
            else if (rdbOption2.Checked == true)
                intSelect = 2;
            else if (rdbOption3.Checked == true)
                intSelect = 3;
            else if (rdbOption4.Checked == true)
                intSelect = 4;
            else
                intSelect = 0;

            //if the key already exist then update the value of the key, if not exists then add the key and its value
            if (objDictionaryAnswer.ContainsKey(intKey))
            {                
                objDictionaryAnswer[intKey]=intSelect;
            }
            else
            {
                objDictionaryAnswer.Add(intKey, intSelect);
            }          
        }


        //Method--to get selection of RadioButton corresponding to the Question
        private void CheckInDictionary(int  intKey)
        {
            //int variable to get if one of the RadioButton is selected or not
            int intSelection=0;         
            
            if (objDictionaryAnswer.ContainsKey(intKey))
            {
                intSelection=objDictionaryAnswer[intKey];
            }      
            
            //Call method to unselect the radiobutton
            UnselectRadioButtion();

            //switch to determine which of the RadioButton should be checked based on intSelection variable
            switch (intSelection)
            {          
                case 0:
                    break;
                case 1:
                    rdbOption1.Checked = true;
                    break;
                case 2:
                    rdbOption2.Checked = true;
                    break;
                case 3:
                    rdbOption3.Checked = true;
                    break;
                case 4:
                    rdbOption4.Checked = true;
                    break;                
            }
        }

        //Method-to unselect all of the RadioButton
        private void UnselectRadioButtion()
        {
            rdbOption1.Checked = false;
            rdbOption2.Checked = false;
            rdbOption3.Checked = false;
            rdbOption4.Checked = false;
        }

     
  
        //Method--to check to enable or disable Previous and Next button and to show Submit button or not
        private void Check()
        {
            //int variable to get the SerialNumber of the question from the form
            int intRow=Convert.ToInt32(lblSn.Text.ToString());

            //if the question is last, disable the Next button and show Submit button
            if (intRow == objCurrencyManager.Count)
            {
                btnMoveNext.Enabled = false;
                btnSubmit.Visible = true;
                grpGoTo.Visible = true;
            }

                //if the question is first, disable the Previous button
            else if(intRow==1)
            {
                btnMovePrevious.Enabled = false;
            }
                // if the question is neither first nor last, enable both Previous and Next button
            else
            {
                btnMoveNext.Enabled = true;
                btnMovePrevious.Enabled = true;
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {            
            if (rdbOption1.Checked == true || rdbOption2.Checked == true || rdbOption3.Checked == true || rdbOption4.Checked == true)
            {

                int intKey = Convert.ToInt32(lblSn.Text.ToString());
                //Int variable to get which of the RadioButton is selected or not anyone is selected
                int intSelect;
                if (rdbOption1.Checked == true)
                    intSelect = 1;
                else if (rdbOption2.Checked == true)
                    intSelect = 2;
                else if (rdbOption3.Checked == true)
                    intSelect = 3;
                else if (rdbOption4.Checked == true)
                    intSelect = 4;
                else
                    intSelect = 0;

                //if the key already exist then update the value of the key, if not exists then add the key and its value
                if (objDictionaryAnswer.ContainsKey(intKey))
                {
                    if (objDictionaryAnswer[intKey] != intSelect)
                    {
                        DatabaseManipulationForSubmit();             
                    }
                }
                else
                {
                    DatabaseManipulationForSubmit();             
                }
            }
            else
            {
                AddToDictionary(Convert.ToInt32(lblSn.Text.ToString()));                
            }

            

            int intNumberOfRows = dt.Rows.Count;

            System.Collections.ArrayList intList = new System.Collections.ArrayList();
            for (int i = 1; i <= intNumberOfRows; i++)
            {
                if(objDictionaryAnswer[i]==0)
                {
                    intList.Add(i);
                }
                
            }

            StringBuilder objStringBuilder = new StringBuilder();
            if (intList.Count > 0)
            {
                objStringBuilder.AppendLine("The following question has not been attempted." +
                    "Please attempt all of the question....");
                int intNumber = 1;
                foreach (int i in intList)
                {                    
                    if(intNumber==intList.Count)                    
                    {
                        objStringBuilder.Append(i.ToString());
                    }                        
                    else
                    {
                        objStringBuilder.Append(i.ToString() + ",");
                        intNumber++;
                    }
                        
                    
                }
                objStringBuilder.AppendLine(String.Empty);
                objStringBuilder.AppendLine("Note:");
                objStringBuilder.AppendLine("i.  You can type question no. in GoTo section and click Go button to go to corresponding question.");
                objStringBuilder.AppendLine("ii. After attempting all questions, click Submit button again to proceed.");
                MessageBox.Show(objStringBuilder.ToString(), this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);                
            }
            else
            {
                objStringBuilder.AppendLine("Thank You! You have attempted all of the questions.");
                objStringBuilder.AppendLine(String.Empty);
                objStringBuilder.AppendLine("Are you sure want to submit?");                
                if (MessageBox.Show(objStringBuilder.ToString(), this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    == DialogResult.Yes)
                {
                    timer.Stop();

                    StringBuilder objStringBuilder1 = new StringBuilder();                    
                    objStringBuilder1.AppendLine("Thank you for the Entrance Exam.");
                    objStringBuilder1.AppendLine(string.Empty);
                    objStringBuilder1.AppendLine("Best of luck for the Result.");
                    objStringBuilder1.AppendLine("Click OK to continue.");
                    MessageBox.Show(objStringBuilder1.ToString(), this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Application.Exit();
                }
            }

            
            
        }

        private void btnSubmit_MouseHover(object sender, EventArgs e)
        {
            btnSubmit.Text = "SUBMIT";
            btnSubmit.Font = new Font("Stencil",12);
        }

        private void btnSubmit_MouseLeave(object sender, EventArgs e)
        {
            btnSubmit.Text = "Click here to submit";
            btnSubmit.Font = new Font("Cambria", 13);
        }

        private void FormExamTest_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(e.CloseReason==System.Windows.Forms.CloseReason.UserClosing)
            {
                e.Cancel = true;
            }
            else
            {
                Application.Exit();
            }
        }

        private void txtQuestionNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if((!Char.IsDigit(e.KeyChar)) && (e.KeyChar!=Convert.ToChar(Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void btnGo_Click(object sender, EventArgs e)
        {    
            
            if (rdbOption1.Checked == true || rdbOption2.Checked == true || rdbOption3.Checked == true || rdbOption4.Checked == true)
            {
                int intKey = Convert.ToInt32(lblSn.Text.ToString());
                //Int variable to get which of the RadioButton is selected or not anyone is selected
                int intSelect;
                if (rdbOption1.Checked == true)
                    intSelect = 1;
                else if (rdbOption2.Checked == true)
                    intSelect = 2;
                else if (rdbOption3.Checked == true)
                    intSelect = 3;
                else if (rdbOption4.Checked == true)
                    intSelect = 4;
                else
                    intSelect = 0;

                //if the key already exist then update the value of the key, if not exists then add the key and its value
                if (objDictionaryAnswer.ContainsKey(intKey))
                {
                    if (objDictionaryAnswer[intKey] != intSelect)
                    {
                        DatabaseManipulationForSubmit();
                    }
                }
                else
                {
                    DatabaseManipulationForSubmit();
                }
            }
            else
            {
                AddToDictionary(Convert.ToInt32(lblSn.Text.ToString()));
            }

                        
            if(txtQuestionNo.Text.Trim().Length>0)
            {
                int intQuestionNo = Convert.ToInt32(txtQuestionNo.Text);

                if ((intQuestionNo > 0) && (intQuestionNo <= objCurrencyManager.Count))
                {
                        AddToDictionary(Convert.ToInt32(lblSn.Text.ToString()));
                        CheckInDictionary(Convert.ToInt32(txtQuestionNo.Text));

                        objCurrencyManager.Position = intQuestionNo - 1;
                        ShowPosition();


                        //Call method to check whether to enable Previous or Next button
                        Check();                   
                }
                else
                {
                    MessageBox.Show("Please type question no. starting from 1 to " + objCurrencyManager.Count, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtQuestionNo.Text = "";
                }
            }
            
            
        }

              

     }
}
