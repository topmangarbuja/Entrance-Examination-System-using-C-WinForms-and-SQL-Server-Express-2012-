﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using ClassLibrary;

namespace EntranceExam
{
    public partial class FormReport : Form
    {
        public FormReport()
        {
            InitializeComponent();
        }

        private void FormReport_Load(object sender, EventArgs e)
        {
            reportViewer1.ProcessingMode= ProcessingMode.Local;
            LocalReport localReport = reportViewer1.LocalReport;
            localReport.ReportPath= @"Reports\ReportResult.rdlc";
            DataSet ds = new DataSet();
            //DataSets.DataSetResult DataSet1 = new DataSets.DataSetResult();
            //DataSet DataSet1 = new DataSet();
            DataTable dt = new DataTable();
            DataTable fetchTable = new DataTable();
            fetchTable = GlobalAccess.dtResult;

            dt.Columns.Add("Sn");
            dt.Columns.Add("Username");
            dt.Columns.Add("Fullname");
            dt.Columns.Add("Totalmarks");
            
            
            foreach (DataRow r in fetchTable.Rows)
            {
                dt.Rows.Add(r[0], r[1], r[2], r[3]);
            }
            ds.Tables.Add(dt);
            //DataSet1.Tables[0].TableName = "DataTable1";

            ReportDataSource d = new ReportDataSource();
            d.Name = "DataSet1";
            d.Value = ds.Tables[0];

            localReport.DataSources.Add(d);
            reportViewer1.SetDisplayMode(DisplayMode.PrintLayout);
            reportViewer1.ZoomMode = ZoomMode.Percent;
            reportViewer1.ZoomPercent=100;

            this.reportViewer1.RefreshReport();
        }
    }
}
