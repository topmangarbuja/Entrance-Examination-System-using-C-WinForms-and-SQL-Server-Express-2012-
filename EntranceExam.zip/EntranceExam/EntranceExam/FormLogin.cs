﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using ClassLibrary;

namespace EntranceExam
{
    public partial class FormLogin : Form
    {
        private LoginAccess loginAccess = new LoginAccess();
        
        String username;
        String password;

        public FormLogin()
        {
            InitializeComponent();            
            txtUsername.Focus();
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {           

            if (loginAccess.HasConnection()!=true )
            {
                //Show error message
                MessageBox.Show(loginAccess.errHasConnection, "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                //Set string to nothing
                loginAccess.errHasConnection = "";

                this.Close();
            }
            
            
        }
        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            username = txtUsername.Text;
            password = txtPassword.Text;
            loginAccess.Login(username,password);
            
            if (loginAccess.errLogin != String.Empty)
            {
                //Show error message
                MessageBox.Show(loginAccess.errLogin,"Login Error",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);

                //Set string to nothing
                loginAccess.errLogin="";
            }
            else if (loginAccess.intCount==1)
            {
                if(UpdateLoginDateAndTime()==true)
                {
                    this.Hide();
                    GlobalAccess.username = username;
                    FormMain formMain = new FormMain();
                    formMain.Show(); 
                }
                else
                {
                    MessageBox.Show("Please try again! Sorry for the inconvenience.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                  
            }             
            else
            {
                 MessageBox.Show("Username and password is not correct.","Login Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                 txtUsername.Clear();
                 txtPassword.Clear();
                 txtUsername.Focus();
            }
           
        }

        private bool UpdateLoginDateAndTime()
        {
            string query = "UPDATE dbo.Users " +
                "SET LoginDate=GetDate() " +
                "WHERE Uname=@username;";
                SqlCommand command=new SqlCommand();
            command.CommandText=query;
            command.Parameters.AddWithValue("@username",username);

            loginAccess.RunQuery(command);

            if (loginAccess.errRunQuery != "")
            {
                //Set variable to default
                loginAccess.errRunQuery="";

                return false;
            }
            else
            {
                return true;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {


        }

        
    }
}
