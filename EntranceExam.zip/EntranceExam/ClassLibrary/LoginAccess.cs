﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

using System.Configuration;


namespace ClassLibrary
{    
    public class LoginAccess
    {        
        SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ToString());
        public String errHasConnection="";
        public String errLogin="";
        public String errRunQuery = "";        
        public int intCount;
        public Boolean HasConnection()
        {
            try
            {
                connection.Open();                
                connection.Close();
                return true;
            }
            catch (Exception ex)
            {
                errHasConnection = ex.Message;                
                return false;
            }
            
        }

        public void Login(String username, String password)
        {
             try
            {                
                String query = "Select Uname FROM dbo.Users " +
                    "WHERE UName=@username " +
                    "And PWord=@password;";
                
                //Open the connection
                connection.Open();                
                SqlCommand command = new SqlCommand(query,connection);

                //Add parameters
                command.Parameters.AddWithValue("@username",username);
                command.Parameters.AddWithValue("@password", password);
                 
                SqlDataReader reader= command.ExecuteReader();  
                intCount=new int();
                while(reader.Read())
                {
                    intCount = intCount + 1;

                }                                              
                connection.Close();
            }
            catch (Exception error)
            {
                //Capture the error
                errLogin=error.Message;
                connection.Close();
            }
        }

        public void RunQuery(SqlCommand command)
        {
            try
            {
                connection.Open();
                command.Connection = connection;
                command.ExecuteNonQuery();
                connection.Close();
            
            }
            catch (Exception error)
            {
                errRunQuery = error.Message;
                connection.Close();
            }
            
        }

    }
}
