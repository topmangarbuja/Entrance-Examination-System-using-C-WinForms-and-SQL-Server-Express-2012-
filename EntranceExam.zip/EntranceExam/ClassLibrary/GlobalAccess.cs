﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;

namespace ClassLibrary
{
    public class  GlobalAccess
    {
        public static String username { get; set; }

        public static DataTable dt;
        public static int time{get;set;}
        public static DataTable dtResult { get; set; }
      
    }
}