﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ClassLibrary
{
    public class DataAccess
    {
        SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ToString());
        public String errHasConnection="";
        public String errLogin="";
        public String errRunQuery = "";
        public String errRunQueryFillDataSet = "";
        public String errSelectQuery = "";
        public int intNumber;
        public SqlDataReader reader;
        public DataSet dsRunQuery;

        public void RunQuery(SqlCommand command)
        {
            try
            {
                connection.Open();
                command.Connection = connection;
                command.ExecuteNonQuery();
                connection.Close();            
            }
            catch (Exception error)
            {
                errRunQuery = error.Message;
                connection.Close();
            }            
        }


        public void RunQueryFillDataSet(String text)
        {
            try
            {
                connection.Open();
                SqlDataAdapter da = new SqlDataAdapter(text,connection);
                dsRunQuery = new DataSet();                
                da.Fill(dsRunQuery);                
                connection.Close();
            }
            catch (Exception error)
            {
                errRunQueryFillDataSet = error.Message;
                connection.Close();
            }
        }

        //Insert a new autoIncrement column table and merge the source table to it
        public DataTable AutoNumberedTable(DataTable sourceTable)
        {
            DataTable resultTable = new DataTable();

            DataColumn autoNumberColumn = new DataColumn();
            autoNumberColumn.DataType = System.Type.GetType("System.Int16");
            autoNumberColumn.AutoIncrement=true;
            autoNumberColumn.AutoIncrementSeed=1;
            autoNumberColumn.AutoIncrementStep=1;
            resultTable.Columns.Add(autoNumberColumn);
            resultTable.Merge(sourceTable);         
            return resultTable;
        }

        public void SelectQuery(SqlCommand command)
        {
            try
            {
                connection.Open();
                command.Connection = connection;                
                intNumber= Convert.ToInt16(command.ExecuteScalar());                               
                connection.Close();
            }
            catch (Exception error)
            {
                errSelectQuery = error.Message;
                connection.Close();
            }
        }
    }
}
