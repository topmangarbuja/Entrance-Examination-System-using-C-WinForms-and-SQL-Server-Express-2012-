﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ClassLibrary;
using System.Data.SqlClient;

namespace ControlLibrary
{
    public partial class CreateQuestion : UserControl
    {
        public CreateQuestion()
        {
            InitializeComponent();
        }

        private DataAccess dataAccess;
        private int intQuestionId;

        private Boolean ProcessSave()
        {
            if (txtQuestion.Text.Trim().Length < 1 || txtCorrectAnswer.Text.Trim().Length < 1
               || txtOption1.Text.Trim().Length < 1 || txtOption2.Text.Trim().Length < 1 
                || txtOption3.Text.Trim().Length<1)
            {
                //Show error message
                MessageBox.Show("Please enter all of the required fields!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            
                return false;
            }
            else if(nudMarks.Value<1)
            {
                //Show error message
                MessageBox.Show("Please set Marks to at least 1 !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
            else return true;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            dataAccess = new DataAccess();
            if (ProcessSave() == true)
            {
                if (MessageBox.Show("Are you sure want to create the new question?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
               == DialogResult.Yes)
                {
                    ////Call method to get question id
                    //GetQuestionId();
                    //if (dataAccess.errSelectQuery != "")
                    //{
                    //    MessageBox.Show(dataAccess.errSelectQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //    dataAccess.errSelectQuery = "";

                    //    MessageBox.Show("Try again, please!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);


                    //}
                    //else
                    //{
                    //    intQuestionId = dataAccess.intNumber + 1;
                    //}

                    //Call method to insert question
                    InsertQuestion();
                    if (dataAccess.errRunQuery != "")
                    {
                        MessageBox.Show(dataAccess.errRunQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        dataAccess.errRunQuery = "";
                        MessageBox.Show("Try again, please!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show("Data saved successfully!", "Succeed");
                        //Clear the fields
                        Clear();
                    }

                }
            }
        }


        //Methods for Question Insertion
        #region InsertQuestion,GetQuestionId,InsertOption
        
        private void GetQuestionId()
        {
            dataAccess = new DataAccess();
            SqlCommand command = new SqlCommand();
            command.CommandText = "SELECT Max(QuestionId) From Question";
            dataAccess.SelectQuery(command);
        }

        private void InsertQuestion()
        {
            dataAccess = new DataAccess();
            SqlCommand command = new SqlCommand();
            command.CommandText = "DECLARE @intId As Int=(SELECT MAX(QuestionId) FROM Question);"+
                "INSERT INTO Question(QuestionId,Question,AnswerRtf,AnswerText,Marks,Option1,Option2,Option3) "+
                "VALUES(@intId+1,@question,@answerMemo,@answerText,@marks,@opt1,@opt2,@opt3);";
            //command.Parameters.AddWithValue("@id", intQuestionId);
            command.Parameters.AddWithValue("@question", txtQuestion.Rtf);
            command.Parameters.AddWithValue("@answerMemo", txtCorrectAnswer.Rtf);
            command.Parameters.AddWithValue("@answerText", txtCorrectAnswer.Text);
            command.Parameters.AddWithValue("@marks", nudMarks.Value);
            command.Parameters.AddWithValue("@opt1", txtOption1.Rtf);
            command.Parameters.AddWithValue("@opt2", txtOption2.Rtf);
            command.Parameters.AddWithValue("@opt3", txtOption3.Rtf);


            dataAccess.RunQuery(command);
        }
        #endregion

        //Method to clear the fields
        private void Clear()
        {
            txtQuestion.Text = "";
            txtCorrectAnswer.Text = "";
            txtOption1.Text = "";
            txtOption2.Text = "";
            txtOption3.Text = "";
            txtQuestion.Focus();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //Clear the fields
            Clear();
        }

        private void textBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            
            if(e.KeyChar==Convert.ToChar(Keys.Enter))
            {
                e.Handled = true;
            }
        }  
                
    }
}
