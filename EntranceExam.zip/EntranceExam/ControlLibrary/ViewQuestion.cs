﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ClassLibrary;
using System.Data.SqlClient;

namespace ControlLibrary
{
    public partial class ViewQuestion : UserControl
    {
        private DataAccess dataAccess;
        private DataSet ds = new DataSet();
        private int intQuestionId;
        private int intRowVal;

        public ViewQuestion()
        {
            InitializeComponent();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            dataAccess = new DataAccess();

            String query = "SELECT QuestionId As [Q-Id],Question, AnswerRtf As [Correct Answer],Marks, Option1,Option2,Option3 "+
                "FROM dbo.Question " +
                "ORDER BY QuestionId;";
                dataAccess.RunQueryFillDataSet(query);

                if (dataAccess.errRunQueryFillDataSet != "")
                {
                    //Show error message
                    MessageBox.Show(dataAccess.errRunQueryFillDataSet, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //Set variable to default
                    dataAccess.errRunQueryFillDataSet = "";
                }
                else
                {
                    ds = dataAccess.dsRunQuery;
                    FillDataGridView();
                }

                //Clear the fields
                //Clear();
             
        }

        private void FillDataGridView()
        {
            grdViewQuestion.DataSource = dataAccess.AutoNumberedTable(ds.Tables[0]);
            grdViewQuestion.Columns[0].HeaderText = "Sn";
            grdViewQuestion.Columns[1].Frozen = true;
        }

        private void grdViewQuestion_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            

            //Enable the controls
            EnableControls();

            //Clear the richTextBoxes
            Clear();

            intRowVal = grdViewQuestion.CurrentCell.RowIndex;
            for (int i = 0; i < 7; i++)
            {
                try
                {
                    switch (i)
                    {
                        case 0:
                            intQuestionId = Convert.ToInt32(grdViewQuestion.CurrentRow.Cells["Q-Id"].Value.ToString());
                            txtQuestionId.Text = intQuestionId.ToString();
                            break;
                        case 1:
                            txtQuestion.Rtf = grdViewQuestion.CurrentRow.Cells["Question"].Value.ToString();
                            break;
                        case 2:
                            txtCorrectAnswer.Rtf = grdViewQuestion.CurrentRow.Cells["Correct Answer"].Value.ToString();
                            break;
                        case 3:
                            nudMarks.Value = Convert.ToInt32(grdViewQuestion.CurrentRow.Cells["Marks"].Value.ToString());
                            break;
                        case 4:
                            txtOption1.Rtf = grdViewQuestion.CurrentRow.Cells["Option1"].Value.ToString();
                            break;
                        case 5:
                            txtOption2.Rtf = grdViewQuestion.CurrentRow.Cells["Option2"].Value.ToString();
                            break;
                        case 6:
                            txtOption3.Rtf = grdViewQuestion.CurrentRow.Cells["Option3"].Value.ToString();
                            break;
                    }
                }
                catch(Exception)
                {

                }
                
            }

            //Disable the update button
            btnUpdate.Enabled = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            dataAccess = new DataAccess();

            if (MessageBox.Show("Are you sure want to update question of id: " + intQuestionId+"?","Question",
                MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
            {
                String query = "UPDATE Question " +
                "SET QuestionId=@id,Question=@question,AnswerRtf=@answerRtf,AnswerText=@answerText,Marks=@marks,Option1=@opt1,Option2=@opt2,Option3=@opt3 " +
                "WHERE QuestionId=" + intQuestionId + ";";
                SqlCommand command = new SqlCommand();
                command.CommandText = query;
                command.Parameters.AddWithValue("@id", txtQuestionId.Text.ToString());
                command.Parameters.AddWithValue("@question", txtQuestion.Rtf);
                command.Parameters.AddWithValue("@answerRtf", txtCorrectAnswer.Rtf);
                command.Parameters.AddWithValue("@answerText", txtCorrectAnswer.Text);
                command.Parameters.AddWithValue("@marks", nudMarks.Value);
                command.Parameters.AddWithValue("@opt1", txtOption1.Rtf);
                command.Parameters.AddWithValue("@opt2", txtOption2.Rtf);
                command.Parameters.AddWithValue("@opt3", txtOption3.Rtf);

                dataAccess.RunQuery(command);

                if (dataAccess.errRunQuery != "")
                {
                    //Show error message
                    MessageBox.Show(dataAccess.errRunQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //Set variable to default
                    dataAccess.errRunQuery = "";
                }
                else
                {
                    btnView_Click(sender, e);
                    MessageBox.Show("Data updated successfully!", "Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //Clear the fields
                    Clear();
                    //Disable the controls
                    DisableControls();
                }
            }            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            dataAccess = new DataAccess();
            if (MessageBox.Show("Are you sure want to delete question of id: " + intQuestionId + "?", "Question",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                String query = "DELETE FROM dbo.Question " +                
                "WHERE QuestionId=" + intQuestionId + ";";
                SqlCommand command = new SqlCommand();
                command.CommandText = query;               

                dataAccess.RunQuery(command);

                if (dataAccess.errRunQuery != "")
                {
                    //Show error message
                    MessageBox.Show(dataAccess.errRunQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //Set variable to default
                    dataAccess.errRunQuery = "";
                }
                else
                {
                    grdViewQuestion.Rows.RemoveAt(intRowVal);
                    MessageBox.Show("Data deleted successfully!", "Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //Clear the fields
                    Clear();
                    //Disable the controls
                    DisableControls();
                }
            }    
        }


        #region Clear,EnableControls and DisableControls method
        //Method to clear the fields
        private void Clear()
        {
            txtQuestion.Text="";
            txtCorrectAnswer.Text="";
            txtOption1.Text="";
            txtOption2.Text="";
            txtOption3.Text = "";
            txtQuestionId.Text = "";
            nudMarks.Value = 0;
        }

        //Method to enable controls
        private void EnableControls()
        {
            txtQuestion.Enabled = true;
            txtCorrectAnswer.Enabled = true;
            txtOption1.Enabled = true;
            txtOption2.Enabled = true;
            txtOption3.Enabled = true;
            txtQuestionId.Enabled = true;
            nudMarks.Enabled = true;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
        }


        //Method to disable controls
        private void DisableControls()
        {
            txtQuestion.Enabled = false;
            txtCorrectAnswer.Enabled = false;
            txtOption1.Enabled = false;
            txtOption2.Enabled = false;
            txtOption3.Enabled = false;
            txtQuestionId.Enabled = false;
            nudMarks.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
        }
        #endregion

        private void ViewQuestion_Load(object sender, EventArgs e)
        {
            //Disable the controls
            DisableControls();
        }

        private void txtQuestionId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar)) && (e.KeyChar != Convert.ToChar(Keys.Back)))
            {
                e.Handled = true;
            }
            
        }

        private void textBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar==Convert.ToChar(Keys.Enter))
            {
                e.Handled = true;   
            }
        }

        private void textBox_TextChanged(object sender, EventArgs e)
        {
            //Enable the update button
            btnUpdate.Enabled = true;
        }

        private void nudMarks_ValueChanged(object sender, EventArgs e)
        {
            //Enable the update button
            btnUpdate.Enabled = true;
        }

       
    }
}
