﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ClassLibrary;
using System.Data.SqlClient;

namespace ControlLibrary
{
    public partial class CreateUser: UserControl
    {
        private DataAccess dataAccess;        

        public CreateUser()
        {
            InitializeComponent();
            
        }

        private Boolean ProcessSave()
        {
            if (txtUsername.Text.Trim().Length < 1 || txtPassword.Text.Trim().Length < 1 
               || txtFirstName.Text.Trim().Length<1 || txtLastName.Text.Trim().Length<1 )
            {
                return false;
            }
            else return true;

        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            dataAccess = new DataAccess();
            if (ProcessSave()==true)
            {
                if (MessageBox.Show("Are you sure want to create " + txtUsername.Text + " user?", "User", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                                == DialogResult.Yes)
                {
                    SqlCommand command = new SqlCommand();
                    command.CommandText = "INSERT INTO dbo.Users(Uname,Pword,FirstName,LastName) VALUES(@username,@password,@firstname,@lastname);";
                    command.Parameters.AddWithValue("@username", txtUsername.Text);
                    command.Parameters.AddWithValue("@password", txtPassword.Text);
                    command.Parameters.AddWithValue("@firstname", txtFirstName.Text);
                    command.Parameters.AddWithValue("@lastname", txtLastName.Text);

                    dataAccess.RunQuery(command);

                    if (dataAccess.errRunQuery != "")
                    {
                        //Show error message
                        MessageBox.Show(dataAccess.errRunQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //Set variable to default
                        dataAccess.errRunQuery = "";
                    }
                    else
                    {
                        //Show error message
                        MessageBox.Show("Data saved successfully!", "Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Clear the fields
                        Clear();
                    }
                }               
            }
            else
            {
                //Show error message
                MessageBox.Show("Please enter all of the required fields!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
             
            
        }

        private void Clear()
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtUsername.Focus();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //Clear the fields
            Clear();
        }
    }
}
