﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ClassLibrary;
using System.Data.SqlClient;

namespace ControlLibrary
{    
    public partial class ViewUser : UserControl
    {
        private DataAccess dataAccess;
        private DataSet ds = new DataSet();
        private String strUsername;
        private int intRowVal;
        public ViewUser()
        {
            InitializeComponent();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            dataAccess = new DataAccess();
            String query = "Select Uname As [Username],Pword As [Password], FirstName As [First Name],LastName As [Last Name],LoginDate from dbo.Users ORDER BY Uname;";
            dataAccess.RunQueryFillDataSet(query);
   
            if (dataAccess.errRunQueryFillDataSet!="")
            {
                //Show error message
                MessageBox.Show(dataAccess.errRunQueryFillDataSet, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Set variable to default
                dataAccess.errRunQueryFillDataSet = "";
            }
            else
            {        
                ds= dataAccess.dsRunQuery;
                FillDataGridView();
            }

            //Clear the fields
            Clear();             
        }


        private void FillDataGridView()
        {
            grdViewUser.DataSource = dataAccess.AutoNumberedTable(ds.Tables[0]);
            grdViewUser.Columns[0].HeaderText = "Sn";
            grdViewUser.Columns[1].Frozen = true;
        }

        private void grdViewUser_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            intRowVal = grdViewUser.CurrentCell.RowIndex;
            //Enable the controls
            EnableControl();
            //Clear the fields
            Clear();

            for (int i = 0; i <= 4; i++)
            {
                switch (i)
                {
                    case 0:
                        strUsername = grdViewUser.CurrentRow.Cells["Username"].Value.ToString();
                        txtUsername.Text = strUsername;
                        break;
                    case 1:
                        txtPassword.Text = grdViewUser.CurrentRow.Cells["Password"].Value.ToString();
                        break;
                    case 2:
                        txtFirstName.Text = grdViewUser.CurrentRow.Cells["First Name"].Value.ToString();
                        break;
                    case 3:
                        txtLastName.Text = grdViewUser.CurrentRow.Cells["Last Name"].Value.ToString();
                        break;
                    case 4:
                        txtLoginDate.Text = grdViewUser.CurrentRow.Cells["LoginDate"].Value.ToString();
                        break;
                }

            }
            //Disable the Update button
            btnUpdate.Enabled= false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            dataAccess = new DataAccess();

            if (MessageBox.Show("Are you sure want to update " + strUsername + " user details?", "User", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                SqlCommand command = new SqlCommand();
                command.CommandText = "UPDATE dbo.Users " +
                    "SET Uname=@username,Pword=@password,FirstName=@firstname,LastName=@lastname " +
                    "WHERE Uname='" + strUsername + "'";
                command.Parameters.AddWithValue("@username", txtUsername.Text);
                command.Parameters.AddWithValue("@password", txtPassword.Text);
                command.Parameters.AddWithValue("@firstname", txtFirstName.Text);
                command.Parameters.AddWithValue("@lastname", txtLastName.Text);
                dataAccess.RunQuery(command);

                if (dataAccess.errRunQuery != "")
                {
                    //Show error message
                    MessageBox.Show(dataAccess.errRunQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //Set variable to default
                    dataAccess.errRunQuery = "";
                }
                else
                {
                    btnView_Click(sender, e);
                    MessageBox.Show("Data updated successfully!", "Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //Clear the fields
                    Clear();
                    //Disable the controls
                    DisableControl();
                }
            }
        }
        
        private void Clear()
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtLoginDate.Text = "";
            txtUsername.Focus();
        }

        private void EnableControl()
        {
            txtUsername.Enabled = true;
            txtPassword.Enabled = true;
            txtFirstName.Enabled = true;
            txtLastName.Enabled = true;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
        }
        private void DisableControl()
        {
            txtUsername.Enabled = false;
            txtPassword.Enabled = false;
            txtFirstName.Enabled = false;
            txtLastName.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {                       
            if (MessageBox.Show("Are you sure want to delete "+ strUsername+" user details?","User",MessageBoxButtons.YesNo,MessageBoxIcon.Question)
                ==DialogResult.Yes)
            {
                SqlCommand command = new SqlCommand();
                command.CommandText = "DELETE FROM dbo.Users " +
                    "WHERE Uname='" + strUsername + "';";
                dataAccess.RunQuery(command);

                if (dataAccess.errRunQuery != "")
                {
                    //Show error message
                    MessageBox.Show(dataAccess.errRunQuery, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //Set variable to default
                    dataAccess.errRunQuery = "";
                }
                else
                {
                    grdViewUser.Rows.RemoveAt(intRowVal);
                    MessageBox.Show("Data deleted successfully!. Click View User button to refresh the result box.", "Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //btnView_Click(sender, e);

                    //Clear the fields
                    Clear();
                    //Disable the controls
                    DisableControl();

                }
            }
            
             
        }

        
        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            btnUpdate.Enabled = true;            
        }
        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            btnUpdate.Enabled = true;            
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            btnUpdate.Enabled = true;        

        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            btnUpdate.Enabled = true;            
        }

        private void ViewUser_Load(object sender, EventArgs e)
        {
            //Disable the controls
            DisableControl();
        }            
    }
}
